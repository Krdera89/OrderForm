﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderForm1
{
    
    public class Order
    {
        public string Madden;
        public string NBA2K20;
        public string TurtleBeaches;

    }
}
