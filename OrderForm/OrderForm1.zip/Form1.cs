﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OrderForm1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "1";
            }
            else
            {
                int val = Convert.ToInt32(textBox1.Text);
                val++;
                textBox1.Text = val.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "1";
            }
            else
            {
                int val = Convert.ToInt32(textBox2.Text);
                val++;
                textBox2.Text = val.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                textBox3.Text = "1";
            }
            else
            {
                int val = Convert.ToInt32(textBox3.Text);
                val++;
                textBox3.Text = val.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();// creates an instance of form2 and opens new form2
            frm2.QuantityMadden = Convert.ToInt32(textBox1.Text); ///passes Quantity to madden.

            frm2.Quantity2K20 = Convert.ToInt32(textBox2.Text); ///passes Quantity to 2K.
            frm2.QuantityTutleBeaches = Convert.ToInt32(textBox3.Text); ///passes Quantity to TurtleBeaches .

            frm2.UpdateFields();// creates instance updated fields for my total



            frm2.Show();//shows form 2 


            frm2.MyOrder.Madden = "toal";
            frm2.MyOrder.NBA2K20 = "toal";
            frm2.MyOrder.TurtleBeaches = "toal";// passing the string that is apart of form 2

        }
    }
    }
    

